package myComp;

import humans.Human;
import humans.Schoolboy;

import java.util.Comparator;

public class NumOfSchoolComp implements Comparator<Schoolboy> {

    @Override
    public int compare(Schoolboy o1, Schoolboy o2) {
        return o1.getNumOfSchool()-o2.getNumOfSchool();
    }
}
