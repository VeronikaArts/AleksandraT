package myComp;

import humans.Human;

import java.util.Comparator;

public class TheBestAverageScoreComp implements Comparator<Human> {

    @Override
    public int compare(Human o1, Human o2) {
        if (o1.getAverageScore()>o2.getAverageScore())
            return -1;
        else {
            if (o1.getAverageScore()==o2.getAverageScore())
                return 0;
            else return 1;
        }
    }

}
