package com.company;

import humans.Human;
import humans.Schoolboy;
import humans.Student;
import myComp.NumOfSchoolComp;
import myComp.SurnameComp;
import myComp.TheBestAverageScoreComp;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        //стип школьникку: мат,рус,ист,англ-5, оаст 4+ и первое в школьной, призовое в городской, участник областной
        Schoolboy Ivan=new Schoolboy(12,"М","Иван","Скрипкин","первое место","участник","участник",
                true,true,5,32);//1
        Schoolboy Oleg=new Schoolboy(15,"М","Олег","Копков","-","-","-",
                false,true,4.7,6);
        Schoolboy Evgeny=new Schoolboy(14,"М","Евгений","Жуков","первое место","-","-",
                false,true,4.2,8);
        Schoolboy Masha=new Schoolboy(13,"Ж","Маша","Воронина","первое место","участник","-",
                false,true,4.2,32);
        Schoolboy Vika=new Schoolboy(16,"Ж","Вика","Терентьева","первое место","первое место","участник",
                true,true,4.8,8);//1

        Schoolboy Diana=new Schoolboy(11,"Ж","Диана","Заиграева","-","-","-",
                false,true,4.3,2);

        Schoolboy Sonya=new Schoolboy(14,"Ж","Соня","Маликова","-","-","-",
                false,true,4.8,32);

        ArrayList<Schoolboy> schoolboysArray=new ArrayList<>();
        schoolboysArray.add(Ivan);
        schoolboysArray.add(Oleg);
        schoolboysArray.add(Evgeny);
        schoolboysArray.add(Masha);
        schoolboysArray.add(Vika);
        schoolboysArray.add(Diana);
        schoolboysArray.add(Sonya);

        //стип судента: средний балл 4,75+ и курсавая на 5
        Student Valera=new Student(22,"М","Валера","Иванов",0,4.0);
        Student Ksenia=new Student(20,"Ж","Ксения","Смирнова",4,4.75);
        Student Daniil=new Student(21,"М","Даниил","Васнецов",5,4.75);//1
        Student Liza=new Student(22,"Ж","Лиза","Елиссева",5,5);//1
        Student Roma=new Student(20,"М","Рома","Кошкин",0,3);
        Student Dasha=new Student(21,"Ж","Даша","Шишкина",4,4.0);

        ArrayList<Student> studentArray=new ArrayList<>();
        studentArray.add(Valera);
        studentArray.add(Ksenia);
        studentArray.add(Daniil);
        studentArray.add(Liza);
        studentArray.add(Roma);
        studentArray.add(Dasha);

        ArrayList<Human> isScholarshipArray=new ArrayList<>();

        System.out.println("Девочки, получившие первые места на олимпиадах:");
        for (int i=0;i<schoolboysArray.size();i++){
            if(schoolboysArray.get(i).getGender().equals("Ж") && (schoolboysArray.get(i).getIsOlympiadSchool().equals("первое место") ||
                    schoolboysArray.get(i).getIsOlympiadRegional().equals("первое место") ||
                    schoolboysArray.get(i).getIsOlympiadUrban().equals("первое место")) )
                System.out.println(schoolboysArray.get(i).toString());

            if (schoolboysArray.get(i).IsScholarship()){
                isScholarshipArray.add(schoolboysArray.get(i));
            }
        }

        System.out.println("\nСтуденты, получившие оценки за курсовые работы:");
        for (int i=0;i<studentArray.size();i++){
            if(studentArray.get(i).getaverageCoursework()>2.0)
                System.out.println(studentArray.get(i).toString());

            if (studentArray.get(i).IsScholarship()){
                isScholarshipArray.add(studentArray.get(i));
            }
        }

        System.out.println("\nШкольники и студенты, которые должны получать спец. стипендию:");
        for (int i=0;i<isScholarshipArray.size();i++){
            System.out.println(isScholarshipArray.get(i).toString());
        }

        //new homework
        SurnameComp surnameComp=new SurnameComp();
        isScholarshipArray.sort(surnameComp);
        System.out.println("\nШкольники и студенты, которые должны получать спец. стипендию (по фамилии):");
        for (int i=0;i<isScholarshipArray.size();i++){
            System.out.println(isScholarshipArray.get(i).toString());
        }

        TheBestAverageScoreComp theBestAverageScoreComp =new TheBestAverageScoreComp();
        schoolboysArray.sort(theBestAverageScoreComp);
        studentArray.sort(theBestAverageScoreComp);

        System.out.println("\nЛучший школьник:");
        System.out.println(schoolboysArray.get(0));

        System.out.println("Лучший студент:");
        System.out.println(studentArray.get(0));

        NumOfSchoolComp numOfSchoolComp =new NumOfSchoolComp();
        schoolboysArray.sort(numOfSchoolComp);
        schoolboysArray.sort(theBestAverageScoreComp);

        System.out.println("\nШкольники, отсортированные по успеваемости и по номеру школы:");
        for (int i=0;i<schoolboysArray.size();i++){
            System.out.println(schoolboysArray.get(i).toString());
        }

        studentArray.sort(theBestAverageScoreComp);

        System.out.println("\nСтуденты, отсортированные по среднему баллу:");
        for (int i=0;i<studentArray.size();i++){
            System.out.println(studentArray.get(i).toString());
        }

        System.out.println("\nЛучшие по среднему баллу ученики младше 15 лет каждой школы:");
        ArrayList<Schoolboy> array15=new ArrayList<>();

        for (int i=0; i< schoolboysArray.size();i++){
            if (schoolboysArray.get(i).getAge()<15){
                array15.add(schoolboysArray.get(i));
            }
        }

        array15.sort(numOfSchoolComp);
        int index=0;
        System.out.println(array15.get(index).toString());
        for (int i=0; i< array15.size()-1;i++){
            if(array15.get(i).getNumOfSchool()==array15.get(i+1).getNumOfSchool()){
                continue;
            }else {
                index=i+1;
                System.out.println(array15.get(index).toString());
            }
            //System.out.println(array15.get(i).toString());

        }

    }
}
