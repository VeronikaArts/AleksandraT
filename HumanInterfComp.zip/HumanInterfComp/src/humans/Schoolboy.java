package humans;

import java.util.HashMap;
import java.util.Map;

public class Schoolboy extends Human {

    private Map<String,String> olympiad = new HashMap<String,String>();
    private Map<String,Boolean> appraisals = new HashMap<String,Boolean>();
    private int numOfSchool;

    public Schoolboy(int age,String gender, String name, String surname,String school, String urban,String regional,
                     boolean mathRusEnHist5, boolean otherFourPlus,double averageScore, int numOfSchool ){
        super(age,gender,name,surname,averageScore);
        this.olympiad.put("Школьная",school);
        this.olympiad.put("Городская",urban);
        this.olympiad.put("Областная",regional);

        this.appraisals.put("Основные",mathRusEnHist5);
        this.appraisals.put("Остальные",otherFourPlus);
        this.numOfSchool=numOfSchool;

    }

    public int getNumOfSchool(){
        return this.numOfSchool;
    }

    public void setNumOfSchool(int numOfSchool){
        this.numOfSchool=numOfSchool;
    }

    public String getIsOlympiadSchool(){
        return this.olympiad.get("Школьная");
    }

    public String getIsOlympiadUrban(){
        return this.olympiad.get("Городская");
    }

    public String getIsOlympiadRegional(){
        return this.olympiad.get("Областная");
    }

    public Boolean getIsAppraisalsMain(){
        return this.appraisals.get("Основные");
    }

    public Boolean getIsAppraisalsOther(){
        return this.appraisals.get("Остальные");
    }

    @Override
    public boolean IsScholarship(){
        if (this.appraisals.get("Основные")==true && this.appraisals.get("Остальные")==true &&
                (this.olympiad.get("Школьная").equals("первое место") ||
                        this.olympiad.get("Городская").equals("призер") ||
                        this.olympiad.get("Областная").equals("участник") ) )
            return true;
        else return false;
    }

    @Override
    public String toString(){
        String gradeMain;
        String gradeOther;
        String olimpiads;
        if (this.appraisals.get("Основные")==true)
            gradeMain="все <<5>>";
        else gradeMain="не все <<5>>";
        if (this.appraisals.get("Остальные")==true)
            gradeOther="не ниже <<4>>";
        else gradeOther="ниже <<4>>";

        if (this.olympiad.get("Школьная").equals("первое место") ||
                this.olympiad.get("Городская").equals("призер") ||
                this.olympiad.get("Областная").equals("участник") )
            olimpiads="участник/призер/победитель олимпиад";
        else olimpiads="";


        return super.toString()+", средний балл: "+getAverageScore()+", школа №"+numOfSchool+", оценки по основным предметам "+gradeMain+", по остальным: "+gradeOther+","+olimpiads;
    }


}
