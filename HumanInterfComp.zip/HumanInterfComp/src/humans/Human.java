package humans;

public abstract class Human {
    private String name;
    private String surname;
    private String gender;
    private int age;
    private double averageScore;


    public Human(Human human){
        this.age =human.age;
        this.name=human.name;
        this.gender=human.gender;
        this.surname=human.surname;
        this.averageScore=human.averageScore;
    }

    public Human(int age,String gender, String name, String surname,double averageScore){
        this.age=age;
        this.gender=gender;
        this.name=name;
        this.surname=surname;
        this.averageScore=averageScore;
    }

    public Human(){
        this.age=0;
        this.gender="";
        this.name="";
        this.surname="";
        this.averageScore=0;
    }

    public double getAverageScore(){
        return this.averageScore;
    }
    public void setAverageScore(double averageScore){
        this.averageScore=averageScore;
    }

    public void setSurname(String surname){
        this.surname=surname;
    }
    public String getSurname(){
        return this.surname;
    }

    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return this.name;
    }

    public void setAge(int age){
        this.age=age;
    }
    public int getAge(){return this.age;}

    public String getGender(){
        return this.gender;
    }

    public void setGender(String gender){
        this.gender=gender;
    }

    public abstract boolean IsScholarship();

    public String toString(){
        return "Имя: "+name+", Фамилия: "+surname+", пол: "+gender+", возраст: "+age;
    }


}
