package humans;

import java.util.HashMap;
import java.util.Map;

public class Student extends Human {

    private double averageCoursework;
    //средний балл


    public Student(int age,String gender, String name,String surname,double averageCoursework,double averageScore){
        super(age,gender, name,surname,averageScore);
        this.averageCoursework=averageCoursework;

    }

    public double getaverageCoursework(){
        return this.averageCoursework;
    }
    public void setCourseworkFive(double averageCoursework){
        this.averageCoursework=averageCoursework;
    }

    @Override
    public boolean IsScholarship(){
        if (getAverageScore()>=4.75 && this.averageCoursework==5)
            return true;
        else return false;
    }

    public String toString(){
        return super.toString()+", средний балл: "+getAverageScore()+", оценка за курсовую: "+averageCoursework;
    }






}
