package myInterf;

public interface ScholarshipInterf {

    public boolean IsScholarship();

}
