package com.company;

import java.util.Scanner;

public class Main {

    static int sumWords(String str){
        int amount=0,sum=0;
        String[] words = str.split(" ");
        for (int i=0;i<words.length;i++){
            if(words[i].length()!=1 || words[i].length()!=2)
                amount++;
        }
        sum=amount*10;
        return sum;
    }

    static String noPrepositions(String str){
        String[] words = str.split(" ");
        String finalStr="";
        for (int i=0;i<words.length;i++){
            if(words[i].length()==1 || words[i].length()==2)
                words[i]="";
            finalStr+=words[i]+" ";
        }
        return finalStr;

    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String string_chek="";
        int sum=0;

        System.out.println("Введите текст телеграммы: ");
        string_chek=in.nextLine();

        String s=string_chek.charAt(string_chek.length()-1)+"";
        String textRus = "[а-яА-Я]+";

        if (s.matches(textRus))
            string_chek= string_chek.replaceAll("\\,", " зпт ");
        else
            string_chek= string_chek.replaceAll("\\,", " comma ");


        string_chek = string_chek.trim();
        String finalText=noPrepositions(string_chek);
        finalText=finalText.replaceAll("[\\s]{2,}"," ");
        sum=sumWords(finalText);

        System.out.println("Итоговый текст телеграммы: "+finalText);
        System.out.println("Стоимость телеграммы: "+sum);

    }
}
