package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("Задача: заполнить массив 20 случайными целыми числами(0-1000)." +
                " \nОбразовать новый массив, элементами которого будут  элементы исходногои массива,\n" +
                "оканчивающиеся на 3, отсортированные по убыванию ");

        int[] array = new int[20];
        System.out.print("Исходный массив: ");
        for (int i = 0; i < array.length; i++) {
            array[i]=(int) Math.round((Math.random() * 1000)+1);
            System.out.print(array[i]+" ");
        }

        int count=0;
        for (int i=0;i< array.length;i++){
            if(array[i]%10==3){
                count++;
            }
        }

        if(count!=0){
            int[] new_array = new int[count];
            int j=0;

            while (j<count) {
                for (int i = 0; i < array.length; i++) {
                    if (array[i] % 10 == 3) {
                        new_array[j] = array[i];
                        j++;
                    }
                }
            }

            //сортировка

            boolean isSorted = false;
            int buf;
            while(!isSorted) {
                isSorted = true;
                for (int i = 0; i < new_array.length-1; i++) {
                    if(new_array[i] < new_array[i+1]){
                        isSorted = false;

                        buf = new_array[i];
                        new_array[i] = new_array[i+1];
                        new_array[i+1] = buf;
                    }
                }
            }


            System.out.print("\nНовый массив: ");
            for (int i = 0; i < new_array.length; i++) {
                System.out.print(new_array[i]+" ");

            }

        }else System.out.println("Чисел, удовлетворяющих условию нет в исходном массиве");


    }
}
