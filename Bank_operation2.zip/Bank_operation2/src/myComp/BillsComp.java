package myComp;

import com.company.Bill;

import java.util.Comparator;

public class BillsComp implements Comparator<Bill> {
    @Override
    public int compare(Bill K, Bill T){
        return (K.getBankAccount1().compareTo(T.getBankAccount1()));

    }
}