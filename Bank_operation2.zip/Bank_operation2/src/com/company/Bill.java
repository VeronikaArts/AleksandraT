package com.company;

public class Bill {

    private String bankAccount1;
    private double accountAmount;

    Bill(String bankAccount1,double accountAmount){
        this.bankAccount1=bankAccount1;
        this.accountAmount=accountAmount;
    }

    Bill(){return;}

    public String getBankAccount1() {
        return bankAccount1;
    }

    public double getAccountAmount() {
        return accountAmount;
    }

    public void setAccountAmountPlus(double transferAmount){
        this.accountAmount+=transferAmount;
    }

    public void setAccountAmountMinus(double transferAmount){
        this.accountAmount-=transferAmount;
    }
    public String toString(){
        return "Счет: "+bankAccount1+", сумма: "+accountAmount;
    }
}
