package com.company;

import myComp.BillsComp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static File inFile = new File("data.txt");
    static Scanner in = null;

    public static boolean N() throws IOException, IllegalStateException {
        try {
            in = new Scanner(inFile);
            return true;
        } catch (IOException e) {
            System.out.println("Файлы не открылись");
            return false;
        }

    }

    public static boolean isOkDate(int day, int month){
        if ((day<1 || day>31) || (month<1 || month>12) ){
            return false;
        }else return true;

    }

    static Scanner s=new Scanner(System.in);
    public static int getInt(int amount) throws IOException,IllegalStateException {
        int x=0;
        while (true) {
            if (s.hasNextInt()) {

                x = s.nextInt();
                if (x>0 && x<=amount){
                    return x;
                }
                else System.out.println("Такого номера нет. Выберите из преложенных");

            } else {
                System.out.println("Это не число");
                String str = s.nextLine();
            }
        }

    }

    public static void main(String[] args) throws IOException {
        if (!N())
            return;

        ArrayList <Bank> operations = new ArrayList<>();
        ArrayList <Bill> bills = new ArrayList<>();

        try {
            ArrayList<String> stringArrayList = new ArrayList<>();
            String bankAccount1, bankAccount2;

            int day, month, year;
            double accountAmount, transferAmount;
            //считывание в массив строк
            while (in.hasNext()) {
                stringArrayList.add(in.nextLine());
            }
            in.close();

            for (int i = 0; i < stringArrayList.size(); i++) {
                String space = " +";
                String[] str1 = stringArrayList.get(i).split(space);
                if (str1.length <= 2) {
                    bankAccount1 = str1[0];
                    accountAmount = Double.parseDouble(str1[1]);

                    if (accountAmount>=0) {
                        Bill newBill = new Bill(bankAccount1, accountAmount);
                        bills.add(newBill);
                    }
                    else {
                        System.err.println("Некорректная сумма на счете: " + accountAmount);
                        continue;
                    }

                } else {
                    String[] str2 = stringArrayList.get(i).split(space);
                    String dot = "[.]";
                    String[] date = str2[0].split(dot);

                    day = Integer.parseInt(date[0]);
                    month = Integer.parseInt(date[1]);
                    year = Integer.parseInt(date[2]);
                    bankAccount1 = str2[1];
                    bankAccount2 = str2[2];
                    transferAmount = Double.parseDouble(str2[3]);

                    LocalDate transferDate = LocalDate.of(year, month, day);
                    Bank newOperation=new Bank(bankAccount1,transferDate,bankAccount2,transferAmount);
                    operations.add(newOperation);

                }
            }

            LocalDate dateNow=LocalDate.now();
            LocalDate dateOperation;
            for (int h=0;h<operations.size();h++){
                transferAmount=operations.get(h).getSum();
                bankAccount2=operations.get(h).getBankAccount2();
                bankAccount1=operations.get(h).getBankAccount1();
                dateOperation=operations.get(h).getDateTransfer();
                    if (dateNow.isAfter(dateOperation)) {
                        for (int i = 0; i < bills.size(); i++) {

                            if (bills.get(i).getBankAccount1().equals(bankAccount1)) {
                                if (bills.get(i).getAccountAmount() < transferAmount) {
                                    System.err.print("Операция: счет списания: " + bankAccount1
                                            + ", сумма: " + transferAmount + ", дата: " + dateOperation + ", счет получения: " +
                                            bankAccount2 + " невозможна. ");
                                    System.err.println("Сумма на счете меньше суммы перевода.");
                                    continue;
                                } else {
                                    bills.get(i).setAccountAmountMinus(transferAmount);
                                    for (int j = 0; j < bills.size(); j++) {
                                        if (bills.get(j).getBankAccount1().equals(bankAccount2)) {
                                            bills.get(j).setAccountAmountPlus(transferAmount);
                                        }
                                    }

                                }

                            }
                        }
                    }
                }

            BillsComp billsComp=new BillsComp();
            bills.sort(billsComp);

            for (int i = 0; i < bills.size(); i++) {
                System.out.print(i+1+".");
                System.out.println(bills.get(i));
            }

            //доп
            bills.clear();

            for (int i = 0; i < stringArrayList.size(); i++) {
                String space = " +";
                String[] str1 = stringArrayList.get(i).split(space);
                if (str1.length <= 2) {
                    bankAccount1 = str1[0];
                    accountAmount = Double.parseDouble(str1[1]);
                    if (accountAmount>=0) {
                        Bill newBill = new Bill(bankAccount1, accountAmount);
                        bills.add(newBill);//массив счетов
                    }
                    else continue;
                } else break;

            }
            bills.sort(billsComp);

            int flag=0;
            while (flag!=1){
                System.out.println("Выберите номер счета(1,2,3...)");
                int number =getInt(bills.size());
                Bill billsChoice=bills.get(number-1);
                double sumBefore=billsChoice.getAccountAmount();

                if (number<=operations.size()){
                    System.out.println("Введите дату начала периода (дд-мм-гг) ");
                    Scanner scanner=new Scanner(System.in);
                    String dateStart=scanner.nextLine();
                    if (dateStart.matches("[0-9]*[0-9]-[0-9]*[0-9]-[0-9]*[0-9]")){
                        String symbol = "[-]";
                        String[] dataStr =dateStart.split(symbol);
                        if (isOkDate(Integer.parseInt(dataStr[0]),Integer.parseInt(dataStr[1]))==true){

                            LocalDate localDateStart =LocalDate.of(Integer.parseInt(dataStr[2]),Integer.parseInt(dataStr[1]),Integer.parseInt(dataStr[0]));
                            System.out.println("Введите дату окончания периода (дд-мм-гг) ");
                            String dateEnd=scanner.nextLine();
                            if (dateEnd.matches("[0-9]*[0-9]-[0-9]*[0-9]-[0-9]*[0-9]")){
                                String[] dataStrEnd =dateEnd.split(symbol);

                                if (isOkDate(Integer.parseInt(dataStrEnd[0]),Integer.parseInt(dataStrEnd[1]))==true) {
                                    LocalDate localDateEnd = LocalDate.of(Integer.parseInt(dataStrEnd[2]), Integer.parseInt(dataStrEnd[1]), Integer.parseInt(dataStrEnd[0]));

                                    double sumPeriod = 0, write_offs = 0;
                                    for (int i = 0; i < operations.size(); i++) {
                                        //Сумма на счете до начала периода:
                                        //если дата перевода ДО даты старта то
                                        if (operations.get(i).getDateTransfer().isBefore(localDateStart)) {

                                            if (operations.get(i).getBankAccount2().equals(billsChoice.getBankAccount1())) {
                                                sumBefore += operations.get(i).getSum();
                                            }

                                            if (operations.get(i).getBankAccount1().equals(billsChoice.getBankAccount1())) {
                                                sumBefore -= operations.get(i).getSum();
                                            }
                                        }

                                        //все поступления в периоде
                                        if (operations.get(i).getDateTransfer().isBefore(localDateEnd) &&
                                                operations.get(i).getDateTransfer().isAfter(localDateStart)) {

                                            if (operations.get(i).getBankAccount2().equals(billsChoice.getBankAccount1())) {
                                                sumPeriod += operations.get(i).getSum();
                                                billsChoice.setAccountAmountPlus(operations.get(i).getSum());
                                            }

                                        }

                                        //все списания в периоде
                                        if (operations.get(i).getDateTransfer().isBefore(localDateEnd) &&
                                                operations.get(i).getDateTransfer().isAfter(localDateStart)) {

                                            if (operations.get(i).getBankAccount1().equals(billsChoice.getBankAccount1())) {
                                                if (billsChoice.getAccountAmount() < operations.get(i).getSum()) {
                                                    System.err.print(operations.get(i).toString() + " невозможна. ");
                                                    System.err.println("Сумма на счете меньше суммы перевода");
                                                    continue;
                                                } else {
                                                    billsChoice.setAccountAmountMinus(operations.get(i).getSum());
                                                    write_offs += operations.get(i).getSum();
                                                }
                                            }

                                        }


                                    }
                                    System.out.println("Счет: " + billsChoice.getBankAccount1() + "\nСумма на счете до начала периода: " + sumBefore);
                                    System.out.println("Поступелния на счет в периоде: " + sumPeriod);
                                    System.out.println("Списания со счета в периоде: " + write_offs);
                                    System.out.println("Исходящий остаток: " + billsChoice.getAccountAmount());
                                    flag = 1;
                                }else {
                                    flag=0;
                                    System.err.println("Неверная дата");
                                }

                            }else {
                                flag=0;
                                System.err.println("Неправильная дата");
                            }
                        }else {
                            flag=0;
                            System.err.println("Неверная дата");

                        }
                    }else {
                        flag=0;
                        System.err.println("неправильная дата");
                    }

                }else {
                    flag=0;
                    System.err.println("нет такого счета");
                }

            }



        } catch (ArrayIndexOutOfBoundsException ex) {
            System.err.println("Ошибка переполнения массива");
            return;
        } catch (IllegalStateException q) {
            System.err.println("файл пуст или не читается");
            return;
        } catch (FileNotFoundException e) {
            System.err.println("файл не найден");
        } catch (IOException ex) {
            System.err.println("Операция ввода-вывода завершена неудачно или прервана");
            return;
        }catch (DateTimeException ex){
            System.err.println("Неверная дата");
            return;
        }

    }
}
