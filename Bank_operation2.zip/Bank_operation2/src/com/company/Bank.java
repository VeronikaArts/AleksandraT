package com.company;

import java.time.LocalDate;

public class Bank {
    private String bankAccount1;
    private LocalDate dateTransfer;
    private String bankAccount2;
    private double sum;

    Bank(String bankAccount1, LocalDate dateTransfer, String bankAccount2, double sum){
        this.bankAccount1=bankAccount1;
        this.dateTransfer=dateTransfer;
        this.bankAccount2=bankAccount2;
        this.sum=sum;
    }

    Bank(){
        return;
    }

    public LocalDate getDateTransfer() {
        return dateTransfer;
    }

    public String getBankAccount1() {
        return bankAccount1;
    }

    public double getSum() {
        return sum;
    }

    public String getBankAccount2() {
        return bankAccount2;
    }
}
