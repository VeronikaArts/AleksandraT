package com.company;

public class Main {

    public static void main(String[] args) {

        float[][] znach = new float[7][4];
        float k=0;
        int j=0;
        while (j<1) {
            for (int i=0;i<7;i++){
                znach[i][j]=k;
                k += 0.5;
            }
            j++;
        }
        while (j<2) {
            for (int i=0;i<7;i++){
                znach[i][j]=znach[i][0]*znach[i][0]-10*znach[i][0]+15;
            }
            j++;
        }
        while (j<3) {
            for (int i=0;i<7;i++){
                znach[i][j]= (float) (2*Math.sin(znach[i][0]+Math.PI/3));
            }
            j++;
        }
        while (j<4) {
            for (int i=0;i<7;i++){
                znach[i][j]= (float) Math.pow(Math.E,Math.sqrt(znach[i][0]));
            }
            j++;
        }

        System.out.format("%-20s | %-20s | %-20s | %-20s \n",
                "Аргумент",
                "f(x)= x^2-10x+15", "f(x)= 2∗sin(x+π/3)",
                "f(x)=e^(√x)");

        for (int i = 0; i< 7; i++) {
            for (j=0;j<4;j++){
                System.out.format("%-23.2f ",znach[i][j]);
            }
            System.out.println();
        }


    }
}
