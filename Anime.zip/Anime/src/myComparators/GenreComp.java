package myComparators;

import com.company.Film;

import java.util.Comparator;

public class GenreComp implements Comparator<Film> {

    @Override
    public int compare(Film f1, Film f2){

        return f1.getGenre().compareTo(f2.getGenre());

    }
}
