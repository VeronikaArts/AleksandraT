package myComparators;

import com.company.Film;

import java.util.Comparator;

public class RatingComp implements Comparator<Film> {
    @Override
    public int compare(Film f1, Film f2){

        if (f1.getRating()- f2.getRating()>0)
            return -1;
        else {
            if(f1.getRating()- f2.getRating()==0)
                return 0;
            else return 1;
        }

    }
}
