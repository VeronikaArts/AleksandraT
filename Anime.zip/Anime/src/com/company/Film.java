package com.company;

public class Film {

    private String name;
    private String genre;//жанр
    private int number_of_episodes;
    private float rating;

    public Film(String name, String genre, int number_of_episodes, Float rating){

        this.name=name;
        this.genre=genre;
        this.number_of_episodes=number_of_episodes;
        this.rating= rating;
    }

    public String getName(){
        return name;
    }

    public float getRating() {
        return rating;
    }

    public int getNumber_of_episodes() {
        return number_of_episodes;
    }
    public String getGenre(){
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public void setNumber_of_episodes(int number_of_episodes) {
        this.number_of_episodes = number_of_episodes;
    }


    public String toString(){
        return genre+" "+rating;

    }
}
