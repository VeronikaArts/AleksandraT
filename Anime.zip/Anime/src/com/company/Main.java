package com.company;

import myComparators.GenreComp;
import myComparators.RatingComp;
import myComparators.SeriesComp;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static File inFile= new File("data_anime_rating.txt");
    static Scanner in=null;

    public static boolean N()throws IOException,IllegalStateException{
        try {
            in = new Scanner(inFile);
            return true;
        }catch (IOException e){
            System.err.println("Файлы не открылись");
            return false;
        }
    }

    public static void main(String[] args)  throws IOException {
        if (!N())
            return;

        ArrayList<Film> films = new ArrayList<>();

        try {
            File inFile = new File("data_anime_rating.txt");
            Scanner in = new Scanner(inFile);
            ArrayList<String> strings=  new ArrayList<>();
            Film new_film=null;
            int j=0;
            while (in.hasNextLine()){
                strings.add(in.nextLine());
            }
            in.close();

            while (strings.size()>0){
                new_film =new Film(strings.get(0),strings.get(1),Integer.parseInt(strings.get(2)),
                        Float.parseFloat(strings.get(3)));
                films.add(new_film);
                while(j<4){
                    strings.remove(0);
                    j++;
                }
                new_film=null;
                j=0;
            }
        } catch (FileNotFoundException e) {
            System.err.println("файл не найден");
        } catch (IOException ex) {
            System.err.println("Операция ввода-вывода завершена неудачно или прервана");
            return;
        } catch (ArrayIndexOutOfBoundsException ex) {
            System.err.println("Ошибка переполнения массива");
            return;
        } catch (IllegalStateException q) {
            System.err.println("файл пуст или не читается");
            return;
        }

        //определить количество фильмов драма и тд
        ArrayList<Film> films_seria = new ArrayList<Film>();
        int drama_n=0, comedy_n=0, adventure_n=0;
        for (int i = 0; i < films.size(); i++) {
            if (films.get(i).getGenre().equals("Drama")){
                drama_n++;
                films_seria.add(films.get(i));
            }
            if (films.get(i).getGenre().equals("Comedy"))
                comedy_n++;
            if(films.get(i).getGenre().equals("Adventure"))
                adventure_n++;
        }
        System.out.println("Drama: "+drama_n+"\nComedy: "+comedy_n+"\nAdventure: "+adventure_n);

        //определить и вывести кол серий в 5и самых длинных сериалах драма
        SeriesComp seriesComp= new SeriesComp();
        films_seria.sort(seriesComp);

        System.out.println("\nКоличество серий в 5 самых длинных сериалах <<Drama>>:");
        System.out.format("%-35s | %-16s | %-20s | %-15s \n",
                "Название",
                "Жанр", "Количество серий",
                "Рейтинг");

        for (int i = 0; i < 5; i++) {
            System.out.format("%-35s | %-16s | %-20s | %-15.3f \n",
                    films_seria.get(i).getName(),
                    films_seria.get(i).getGenre(),
                    films_seria.get(i).getNumber_of_episodes(),
                    films_seria.get(i).getRating());
        }

        GenreComp genreComp=new GenreComp();
        RatingComp ratingComp=new RatingComp();
        films.sort(ratingComp);
        films.sort(genreComp);

        //дополнительно
        //самый высокий рейтинг фильма или сериала для каждого жанра в файле
        ArrayList<Film> films_rating= new ArrayList<>();
        int j=0,k=0;
        for (int i = 0; i < films.size(); ) {
            j = i;
            while (i < films.size() && films.get(i).getGenre().equals(films.get(j).getGenre())) {
                i++;
            }
            k=j;
            films_rating.add(films.get(j));
            while (j < i-1 ) {
                if(films.get(j).getRating()<films.get(j+1).getRating()){
                    films_rating.set(k,films.get(j+1));
                }
                j++;

            }
        }

        System.out.println("\nСамый высокий рейтинг фильма или сериала для каждого жанра в файле:");
        System.out.format("%-65s | %-16s | %-20s | %-15s \n",
                "Название",
                "Жанр", "Количество серий",
                "Рейтинг");

        for (int i = 0; i < films_rating.size(); i++) {
            System.out.format("%-65s | %-16s | %-20s | %-15.3f \n",
                    films_rating.get(i).getName(),
                    films_rating.get(i).getGenre(),
                    films_rating.get(i).getNumber_of_episodes(),
                    films_rating.get(i).getRating());
        }


    }
}
