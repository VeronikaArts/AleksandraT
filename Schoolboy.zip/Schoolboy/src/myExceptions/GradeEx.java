package myExceptions;

public class GradeEx extends Throwable{
    private int gradle;

    public GradeEx(int gradle){
        this.gradle=gradle;
    }

    @Override
    public String getMessage() {
        return "Некорректная оценка: " + gradle;
    }
}
