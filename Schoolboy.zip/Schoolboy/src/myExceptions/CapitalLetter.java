package myExceptions;

public class CapitalLetter extends Throwable {
    private String nameEx;

    public CapitalLetter(String nameEx){
        this.nameEx=nameEx;
    }

    @Override
    public String getMessage() {
        return "Некорректное имя: " + nameEx;
    }

}
