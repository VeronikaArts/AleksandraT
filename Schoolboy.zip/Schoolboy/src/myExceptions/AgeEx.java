package myExceptions;

public class AgeEx extends Throwable {
    private int age;

    public AgeEx(int age){
        this.age=age;
    }

    @Override
    public String getMessage() {
        return "Некорректный возраст: " + age;
    }
}
