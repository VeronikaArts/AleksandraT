package myExceptions;

public class OlympiadEx extends Throwable {
    private int olympiad;

    public OlympiadEx(int olympiad){
        this.olympiad=olympiad;
    }

    @Override
    public String getMessage() {
        return "Некорректный балл за олимпиаду: " + olympiad;
    }

}
