package com.company;

import myExceptions.AgeEx;
import myExceptions.CapitalLetter;
import myExceptions.GradeEx;
import myExceptions.OlympiadEx;

public class Schoolboy {
    private String name;
    private int age;
    private int sityOlympiad;
    private int regionalOlympiad;
    private int gradeRus;
    private int gradeMath;

    public Schoolboy(String name, int age, int gradeRus,
                     int gradeMath,int sityOlympiad, int regionalOlympiad )
            throws CapitalLetter, GradeEx, OlympiadEx, AgeEx {

        String s="[А-Я][а-я]+";
        if (!name.matches(s))
            throw new CapitalLetter(name);
        if (age<0)
            throw new AgeEx(age);
        if (gradeMath<2 || gradeMath>5 )
            throw new GradeEx(gradeMath);
        if (gradeRus<2 || gradeRus>5)
            throw  new GradeEx(gradeRus);
        if (sityOlympiad<0 || sityOlympiad>3)
            throw  new OlympiadEx(sityOlympiad);
        if (regionalOlympiad<0 || regionalOlympiad>3)
            throw  new OlympiadEx(regionalOlympiad);

        this.name=name;
        this.age=age;
        this.gradeRus=gradeRus;
        this.gradeMath=gradeMath;
        this.sityOlympiad=sityOlympiad;
        this.regionalOlympiad=regionalOlympiad;
    }
    public void setSityOlympiad(int sityOlympiad){ this.sityOlympiad=sityOlympiad;}
    public int getSityOlympiad(){return this.sityOlympiad; }

    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return this.name;
    }

    public void setAge(int age){ this.age=age; }
    public int getAge(){return this.age;}

    public void setGradeRus(int gradeRus){ this.gradeRus=gradeRus;}
    public int getGradeRus(){return this.gradeRus;}

    public void setGradeMath(int gradeMath){this.gradeMath=gradeMath;}
    public int getGradeMath(){return gradeMath;}

    public void setRegionalOlympiad(int regionalOlympiad){ this.regionalOlympiad=regionalOlympiad;}
    public int getRegionalOlympiad(){return this.regionalOlympiad;}


    public boolean IsScholarship(){
        if (this.gradeMath==5 && this.gradeRus==5 && (this.sityOlympiad!=0 || this.regionalOlympiad!=0))
            return true;
        else return false;
    }

    public String toString(){
        return "Имя: "+name+", оценка по русскому: "+gradeRus+", оценка по математике: "+gradeMath+", место в обл олимп.: "+regionalOlympiad+", место в гор олимп.: "+sityOlympiad;
    }






}
