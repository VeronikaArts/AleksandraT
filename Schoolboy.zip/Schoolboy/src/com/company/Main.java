package com.company;

import myExceptions.AgeEx;
import myExceptions.CapitalLetter;
import myExceptions.GradeEx;
import myExceptions.OlympiadEx;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static Scanner s=new Scanner(System.in);
    public static int getInt(){
        int x=0;
        while (true) {
            if (s.hasNextInt()) {
                x = s.nextInt();

                return x;
            } else {
                System.out.println("Это не число");
                String str = s.nextLine();
            }
        }

    }

    public static void main(String[] args) throws OlympiadEx, CapitalLetter,GradeEx {

        ArrayList<Schoolboy> schoolboysArray = new ArrayList<>();

        int flag=1;
        while (flag==1) {
            try {

                Scanner scanner = new Scanner(System.in);
                String str = "";
                System.out.println("Введите данные об ученике в одной строке через пробел:" +
                        "\nимя, возраст, оценка по русскому, оценка по математике, " +
                        "место в городской олимпиаде, место в областной олимпиаде");

                if (scanner.hasNext())
                    str = scanner.nextLine();

                String s = "\s";
                String strArray[] = str.split(s);
                Schoolboy schoolboy = new Schoolboy(strArray[0], Integer.parseInt(strArray[1]), Integer.parseInt(strArray[2]),
                        Integer.parseInt(strArray[3]), Integer.parseInt(strArray[4]), Integer.parseInt(strArray[5]));
                schoolboysArray.add(schoolboy);

                while (true) {
                    System.out.println("Хотите ввести школьника?\n1.да\n2.нет");
                    int yesNo = getInt();
                    if (yesNo < 1 || yesNo > 2)
                        System.out.println("Неправильный ответ. Попробуйте еще раз");
                    else {
                        if (yesNo == 2) {
                            flag = 0;
                            break;
                        }
                        else break;
                    }
                }

            } catch (CapitalLetter capitalLetter) {
                System.err.println(capitalLetter.getMessage());
            } catch (GradeEx gradeEx) {
                System.err.println(gradeEx.getMessage());
            } catch (OlympiadEx olympiadEx) {
                System.err.println(olympiadEx.getMessage());
            } catch (ArrayIndexOutOfBoundsException exception) {
                System.err.println("Некорректная строка");
            } catch (AgeEx ageEx) {
                ageEx.printStackTrace();
            }

        }

        System.out.println("Школьники-кандидаты на соц. стипендию:");
        for (int i=0; i< schoolboysArray.size();i++){
            if (schoolboysArray.get(i).IsScholarship())
                System.out.println(schoolboysArray.get(i).toString());
        }


    }
}
