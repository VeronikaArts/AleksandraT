package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        //1
        Scanner string_scan = new Scanner(System.in);
        String string;
        System.out.println("Введите строку для проверки слова «ant»: ");
        string= string_scan.nextLine();
        String substring = "ant";

        if (string.contains(substring))
            System.out.println("Введенная строка содержит подстроку «ant» ");
        else System.out.println("Введенная строка не содержит подстроку «ant» ");


        //2
        System.out.println("Введите строку для проверки на номер машины: ");
        string =string_scan.nextLine();

        if((string.matches("\\s*([a-z]||[A-Z])\\s*[0-9]\\s*[0-9]\\s*[0-9]\\s*([a-z]||[A-Z])\\s*([a-z]||[A-Z])\\s*")) || (string.matches("\\s*([а-я]||[А-Я])\\s*[0-9]\\s*[0-9]\\s*[0-9]\\s*([а-я]||[А-Я])\\s*([а-я]||[А-Я])\\s*")))
            System.out.println("Может соответствовать номеру машины");
        else System.out.println("Не может соответствовать номеру машины");

        //3
        System.out.println("Введите строку для удаления заглавных букв: ");
        string = string_scan.nextLine();
        System.out.println("Строка без заглавных букв: ");
        System.out.println(string.replaceAll("[A-ZА-Я]",""));

        //4
        System.out.println("Введите зашифрованный текст: ");
        string=string_scan.nextLine();
        String[] words = string.split(" +");
        String[] revers_str = new String[words.length];
        System.out.println("Расшифрованный текст: ");
        for (int i=0;i<words.length;i++){
            revers_str[i]= new StringBuilder(words[i]).reverse().toString();
            System.out.print(revers_str[i]+" ");
        }

        //5
        System.out.println("\nВведите предложение(слова разделены пробелами и запятыми): ");
        string=string_scan.nextLine();
        words = string.split(" +");
        substring = ",";
        int count3=0;
        for (int i=0;i< words.length;i++){
            if(words[i].contains(substring)){
                if (words[i].length()==4)
                    count3++;
            }else
                if (words[i].length()==3)
                    count3++;

        }
        System.out.println("Количество трехбуквенных слов: "+count3);

        //6
        System.out.println("Введите текст(слова разделены пробелами): ");
        string=string_scan.nextLine();
        String str;
        words = string.split(" +");
        for (int i=0;i< words.length;i++){
            for (int j=i+1; j< words.length; j++){
                if(words[j].length()< words[i].length()){
                    str=words[i];
                    words[i]=words[j];
                    words[j]=str;
                }
            }
        }

        for (int i=0;i<words.length;i++){
            System.out.println(words[i].toString());
        }

    }
}
