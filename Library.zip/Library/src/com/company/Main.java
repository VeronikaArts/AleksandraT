package com.company;

public class Main {

    public static void main(String[] args) {

        Reader Petrov= new Reader("Java 8. Полное руководство","Петров");
        Book Petrovs_book=new Book("Java 8. Полное руководство", "Г. Шилдт",1,4);
        System.out.println(Petrov.getReader_name());
        System.out.println(Petrovs_book.toString());

        Reader Vasechkin= new Reader("Крейцерова соната","Васечкин");
        Book Vasechkins_book=new Book("Крейцерова соната", "Л. Толстой",25,3);
        System.out.println("\n"+Vasechkin.getReader_name());
        System.out.println(Vasechkins_book.toString());

        if (Petrovs_book.isBookDeliveredTime(29,3))
            System.out.println("\n"+Petrov.getReader_name()+" сдал книгу вовремя");


        if(Vasechkins_book.isBookDeliveredTime(29,3)){
            System.out.println("\n"+Vasechkin.getReader_name()+" сдал книгу вовремя");
        }

    }
}
