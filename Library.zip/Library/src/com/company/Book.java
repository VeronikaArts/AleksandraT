package com.company;

public class Book {
    private String books_name;
    private String  author;
    private int day_of_delivery;
    private int month_of_delivery;

    public Book(){
        this("","",0,0);
    }

    public Book(String books_name, String  author, int day_of_delivery, int month_of_delivery){
        this.books_name =books_name;
        this.author = author;
        this.day_of_delivery = day_of_delivery;
        this.month_of_delivery=month_of_delivery;
    }

    public Book(Book book){
        books_name =book.books_name;
        author =book.author;
        day_of_delivery =book.day_of_delivery;
        month_of_delivery=book.month_of_delivery;
    }

    public String getBooks_name(){ return this.books_name; }
    public void setBooks_name(String books_name){
        this.books_name = books_name;
    }

    public String getAuthor(){
        return author;
    }
    public void setAuthor(String author){
        this.author = author;
    }

    public int getDay_of_delivery(){
        return day_of_delivery;
    }
    public void setDay_of_delivery(int day_of_delivery){ this.day_of_delivery = day_of_delivery; }

    public int getMonth_of_delivery(){return month_of_delivery;}
    public void setMonth_of_delivery(int month_of_delivery){ this.month_of_delivery=month_of_delivery;}

    public boolean isBookDeliveredTime(int real_day, int real_month){
        if ((real_day<=this.day_of_delivery && real_month==this.month_of_delivery) || (real_month<this.month_of_delivery)  )
            return true;
        else return false;
    }

    public String toString(){
        return "Название книги: "+books_name+"\nИмя автора: "+ author+"\nДень когда надо сдать книгу: "+day_of_delivery+ "\nМесяц когда надо сдать книгу: "+month_of_delivery;
    }


}
