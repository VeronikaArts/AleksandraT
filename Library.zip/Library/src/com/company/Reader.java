package com.company;

public class Reader {

    private Book book;
    private String reader_name;

    public Reader(){
        this("","",0,0,"");
    }

    public Reader(String books_name, String autor,int day_of_delivery,
                  int month_of_delivery, String reader_name){
        this.book=new Book(books_name,autor,day_of_delivery,month_of_delivery);;
        this.reader_name=reader_name;
    }

    public Reader(Reader reader){
        book=reader.book;
        reader_name=reader.reader_name;

    }

    public Book getBook(){ return this.book; }
    public void setBook(Book book){
        this.book = book;
    }

    public String getReader_name(){
        return reader_name;
    }
    public void setReader_name(String reader_name){ this.reader_name=reader_name; }



}
