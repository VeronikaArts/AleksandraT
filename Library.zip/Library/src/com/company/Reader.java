package com.company;

public class Reader {

    private String books_name;
    private String reader_name;

    public Reader(){
        this("","");
    }

    public Reader(String books_name, String reader_name){
        this.books_name =books_name;
        this.reader_name=reader_name;
    }

    public Reader(Reader reader){
        books_name =reader.books_name;
        reader_name=reader.reader_name;

    }

    public String getBooks_name(){ return this.books_name; }
    public void setBooks_name(String books_name){
        this.books_name = books_name;
    }

    public String getReader_name(){
        return reader_name;
    }
    public void setReader_name(String reader_name){ this.reader_name=reader_name; }



}
