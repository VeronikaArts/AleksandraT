package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("Задача: заполнить массив 20 случайными целыми числами(0-1000). " +
                "\nВ масиве посчитать количество и сумму трехзначных симметричных чисел(121,434)");
        int[] array = new int[20];
        int sum=0, amount=0;

        System.out.print("Массив: ");
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) Math.round((Math.random() * 1000));
            System.out.print(array[i]+" ");
        }

        for(int i=0;i<array.length;i++){
            if(array[i]>99 && array[i]<1000){
                if(array[i]%10==array[i]/100){
                    sum+=array[i];
                    amount++;
                }
            }
        }
        if(amount>0)
            System.out.println("\nСумма: "+sum+"\nКоличество: "+amount);
        else System.out.println("Нет чисел, удовлетворяющих условию");


    }
}
