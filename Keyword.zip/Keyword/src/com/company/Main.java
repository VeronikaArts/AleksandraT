package com.company;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        File inFile = new File("data.txt");
        Scanner in = null;
        Scanner String_Chek = new Scanner(System.in);
        String string_chek;

        try {
            in = new Scanner(inFile);
            String text = new String();
            while (in.hasNext()) {
                if (in.hasNextLine()) {
                    text =text+in.nextLine()+"\n";
                }
            }
            in.close();

            System.out.println("Входной текст: ");
            System.out.println(text);

            System.out.print("Введите контрольное слово: ");
            string_chek = String_Chek.nextLine();

            String string_chek0, string_chek1, string_chek2;
            string_chek0= " "+ string_chek+" ";
            string_chek1= " "+ string_chek+",";
            string_chek2=string_chek+" ";

            String[] Text = text.split("[.?!]");
            int f=-1;

            System.out.println("Вывод: ");
            for (int i=0; i<Text.length; i++) {
                if (Text[i].contains(string_chek0)||Text[i].contains(string_chek1) || Text[i].contains(string_chek2) ) {
                    System.out.println(Text[i]);
                    f++;
                }else {
                    if(f==-1 && i==Text.length-1){
                        System.out.println("Нет предложений");
                    }
                }
            }

        } catch (FileNotFoundException ed){
            System.err.println("файл не найден");
            return;
        } catch (IOException ex) {
            System.out.println("Операция ввода-вывода завершена неудачно или прервана");
            return;
        } catch ( IllegalStateException q){
            System.err.println("Файл пуст или не читается");
            return;
        }

    }
}
