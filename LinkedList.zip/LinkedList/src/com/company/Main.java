package com.company;

import java.util.Collections;
import java.util.LinkedList;

public class Main {

    public static void main(String[] args) {
        LinkedList<Double> linkedList=new LinkedList<>();
        for (int i=0;i<10;i++){
            linkedList.add(((double)(Math.random() * 30)-10));
        }
        System.out.println("Исходный массив: ");
        for (int i=0;i<linkedList.size();i++){
            System.out.printf("%-2.3f %s",linkedList.get(i)," ");
        }

        //отсортировать числа по убыванию;
        Collections.sort(linkedList);
        Collections.reverse(linkedList);
        System.out.println("\nМассив, отсортированный по убыванию: ");
        for (int i=0;i<linkedList.size();i++){
            System.out.printf("%-2.3f %s",linkedList.get(i)," ");
        }

        //определить, есть ли в списке нулевые элементы
        int not0=0;
        for (int i=0;i<linkedList.size();i++){
            if(linkedList.get(i)==0)
                not0=1;
        }
        if (not0==1)
            System.out.println("\nВ массиве есть нулевые элементы");
        else System.out.println("\nВ массиве нет нулевых элементов");

        //добавить в середину списка элемент равный среднему арифметическому между первым и последним элементами списка
        double average;
        average=(linkedList.get(0)+(linkedList.size()-1))/2;
        linkedList.add(linkedList.size()/2,average);
        System.out.printf("%s %-2.3f","Элемент равный среднему арифметическому между первым и последним элементами списка:",average);
        System.out.println("\nМассив, с новым элементом:");
        for (int i=0;i<linkedList.size();i++){
            System.out.printf("%-2.3f %s",linkedList.get(i)," ");
        }

    }
}
