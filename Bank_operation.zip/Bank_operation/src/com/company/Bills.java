package com.company;

public class Bills {

    private String bankAccount1;
    private double accountAmount;

    Bills(String bankAccount1, double accountAmount) {
        this.bankAccount1=bankAccount1;
        this.accountAmount=accountAmount;
    }

    public String toString(){
        return "Счет: "+bankAccount1+", сумма: "+accountAmount;
    }

    public String getBankAccount1(){
        return bankAccount1;
    }

    public double getAccountAmount(){
        return accountAmount;
    }
    public void setAccountAmountPlus(double transferAmount){
        this.accountAmount+=transferAmount;
    }

    public void setAccountAmountMinus(double transferAmount){
        this.accountAmount-=transferAmount;
    }
}
