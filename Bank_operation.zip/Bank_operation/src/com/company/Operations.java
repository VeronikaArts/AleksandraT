package com.company;

import myComp.BillsComp;

import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.util.ArrayList;

public class Operations {

    private ArrayList<Bills> arrayOperations=new ArrayList<>();

    Operations(){
        return;
    }

    public void add(Bills bill){
        this.arrayOperations.add(bill);
    }

    //подается дата перевода
    public void operation(double transferAmount, String bankAccount2, String bankAccount1,LocalDate dateNow, ChronoLocalDate dateOperation){

        //Метод before() проверяет, была ли наша дата раньше той, которую мы передаем в качестве аргумента:
        //если дата из арумента(дата операции) меньше чем текущая то
        if (dateNow.isAfter(dateOperation)){
            for (int i=0;i<arrayOperations.size();i++){
                if(arrayOperations.get(i).getBankAccount1().equals(bankAccount1)){
                    if (arrayOperations.get(i).getAccountAmount()<transferAmount){
                        Transfer transfer=new Transfer(bankAccount1,(LocalDate) dateOperation,bankAccount2,transferAmount);
                        System.err.print(transfer.toString()+" невозможна. ");
                        System.err.println("Сумма на счете меньше суммы перевода");
                        continue;
                    }else {
                        arrayOperations.get(i).setAccountAmountMinus(transferAmount);
                        for (int j=0;j<arrayOperations.size();j++){
                            if (arrayOperations.get(j).getBankAccount1().equals(bankAccount2)){
                                arrayOperations.get(j).setAccountAmountPlus(transferAmount);
                            }
                        }

                    }

                }
            }
        }
        BillsComp billsComp=new BillsComp();
        arrayOperations.sort(billsComp);
    }

    public Bills get(int i){
        return arrayOperations.get(i);
    }

    public int size() {
        return arrayOperations.size();
    }

    public void clear(){
        arrayOperations.clear();
    }



}
