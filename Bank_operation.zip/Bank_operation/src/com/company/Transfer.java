package com.company;

import java.time.LocalDate;

public class Transfer {
    private String bankAccount1;
    private LocalDate dateTransfer;
    private String bankAccount2;
    private double sum;

    Transfer(String bankAccount1, LocalDate dateTransfer, String bankAccount2, double sum){
        this.bankAccount1=bankAccount1;
        this.dateTransfer=dateTransfer;
        this.bankAccount2=bankAccount2;
        this.sum=sum;
    }

    public double getSum(){
        return sum;
    }
    public LocalDate getDateTransfer(){
        return dateTransfer;
    }

    public String getBankAccount1(){
        return bankAccount1;
    }

    public String getBankAccount2(){
        return bankAccount2;
    }

    public String toString(){
        return "Операция: счет списания: "+bankAccount1+", сумма: "+sum+", дата: "+ dateTransfer+", счет получения: "+bankAccount2;
    }

}
