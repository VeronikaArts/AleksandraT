package com.company;

import myComp.BillsComp;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.util.ArrayList;
import java.util.Scanner;


public class Main {
    static File inFile = new File("data.txt");
    static Scanner in = null;

    public static boolean N() throws IOException, IllegalStateException {
        try {
            in = new Scanner(inFile);
            return true;
        } catch (IOException e) {
            System.out.println("Файлы не открылись");
            return false;
        }

    }

    public static boolean isOkDate(int day, int month){
        if ((day<1 || day>31) || (month<1 || month>12) ){
            return false;
        }else return true;

    }

    static Scanner s=new Scanner(System.in);
    public static int getInt(int amount) throws IOException,IllegalStateException {
        int x=0;
        while (true) {
            if (s.hasNextInt()) {

                x = s.nextInt();
                if (x>0 && x<=amount){
                    return x;
                }
                else System.out.println("Такого номера нет. Выберите из преложенных");

            } else {
                System.out.println("Это не число");
                String str = s.nextLine();
            }
        }

    }


    public static void main(String[] args) throws IOException {
        if (!N())
            return;
        Operations operations = new Operations();
        ArrayList<Bills> billsDo=new ArrayList<>();


        try {
            ArrayList<String> stringArrayList = new ArrayList<>();
            ArrayList<Transfer> allTransfersArray=new ArrayList<>();

            String bankAccount1, bankAccount2;

            int day, month, year;
            double accountAmount, transferAmount;
            //считывание в массив строк
            while (in.hasNext()) {
                stringArrayList.add(in.nextLine());
            }
            in.close();


            for (int i = 0; i < stringArrayList.size(); i++) {
                String space = " +";
                String[] str1 = stringArrayList.get(i).split(space);
                if (str1.length <= 2) {
                    bankAccount1 = str1[0];
                    accountAmount = Double.parseDouble(str1[1]);

                    if (accountAmount>=0) {
                        Bills newBill = new Bills(bankAccount1, accountAmount);
                        operations.add(newBill);
                    }
                    else {
                        System.err.println("Некорректная сумма на счете: " + accountAmount);
                        continue;
                    }

                } else {
                    String[] str2 = stringArrayList.get(i).split(space);
                    String dot = "[.]";
                    String[] date = str2[0].split(dot);

                    day = Integer.parseInt(date[0]);
                    month = Integer.parseInt(date[1]);
                    year = Integer.parseInt(date[2]);
                    bankAccount1 = str2[1];
                    bankAccount2 = str2[2];
                    transferAmount = Double.parseDouble(str2[3]);

                    ChronoLocalDate transferDate = LocalDate.of(year, month, day);
                    operations.operation(transferAmount, bankAccount2, bankAccount1, LocalDate.now(), transferDate);
                    LocalDate transferDate1 = LocalDate.of(year, month, day);

                    Transfer transfer=new Transfer(bankAccount1,transferDate1,bankAccount2,transferAmount);
                    allTransfersArray.add(transfer);
                }

            }

            for (int i = 0; i < operations.size(); i++) {
                System.out.print(i+1+".");
                System.out.println(operations.get(i));
            }
            operations.clear();

            //доп

            for (int i = 0; i < stringArrayList.size(); i++) {
                String space = " +";
                String[] str1 = stringArrayList.get(i).split(space);
                if (str1.length <= 2) {
                    bankAccount1 = str1[0];
                    accountAmount = Double.parseDouble(str1[1]);
                    if (accountAmount>=0) {
                        Bills newBill = new Bills(bankAccount1, accountAmount);
                        operations.add(newBill);
                        billsDo.add(newBill);
                    }
                    else continue;


                } else break;

            }
            BillsComp billsComp=new BillsComp();
            billsDo.sort(billsComp);

            int flag=0;
            while (flag!=1){
                System.out.println("Выберите номер счета(1,2,3...)");
                int number =getInt(billsDo.size());
                Bills billsChoice=billsDo.get(number-1);
                double sumBefore=billsChoice.getAccountAmount();

                if (number<=operations.size()){
                    System.out.println("Введите дату начала периода (дд-мм-гг) ");
                    Scanner scanner=new Scanner(System.in);
                    String dateStart=scanner.nextLine();
                    if (dateStart.matches("[0-9]*[0-9]-[0-9]*[0-9]-[0-9]*[0-9]")){
                        String symbol = "[-]";
                        String[] dataStr =dateStart.split(symbol);
                        if (isOkDate(Integer.parseInt(dataStr[0]),Integer.parseInt(dataStr[1]))==true){

                            LocalDate localDateStart =LocalDate.of(Integer.parseInt(dataStr[2]),Integer.parseInt(dataStr[1]),Integer.parseInt(dataStr[0]));
                            System.out.println("Введите дату окончания периода (дд-мм-гг) ");
                            String dateEnd=scanner.nextLine();
                            if (dateEnd.matches("[0-9]*[0-9]-[0-9]*[0-9]-[0-9]*[0-9]")){
                                String[] dataStrEnd =dateEnd.split(symbol);

                                if (isOkDate(Integer.parseInt(dataStrEnd[0]),Integer.parseInt(dataStrEnd[1]))==true) {
                                    LocalDate localDateEnd = LocalDate.of(Integer.parseInt(dataStrEnd[2]), Integer.parseInt(dataStrEnd[1]), Integer.parseInt(dataStrEnd[0]));

                                    double sumPeriod = 0, write_offs = 0;
                                    for (int i = 0; i < allTransfersArray.size(); i++) {
                                        //Сумма на счете до начала периода:
                                        //если дата перевода ДО даты старта то
                                        if (allTransfersArray.get(i).getDateTransfer().isBefore(localDateStart)) {

                                            if (allTransfersArray.get(i).getBankAccount2().equals(billsChoice.getBankAccount1())) {
                                                sumBefore += allTransfersArray.get(i).getSum();
                                            }

                                            if (allTransfersArray.get(i).getBankAccount1().equals(billsChoice.getBankAccount1())) {
                                                sumBefore -= allTransfersArray.get(i).getSum();
                                            }
                                        }

                                        //все поступления в периоде
                                        if (allTransfersArray.get(i).getDateTransfer().isBefore(localDateEnd) &&
                                                allTransfersArray.get(i).getDateTransfer().isAfter(localDateStart)) {

                                            if (allTransfersArray.get(i).getBankAccount2().equals(billsChoice.getBankAccount1())) {
                                                sumPeriod += allTransfersArray.get(i).getSum();
                                                billsChoice.setAccountAmountPlus(allTransfersArray.get(i).getSum());
                                            }

                                        }

                                        //все списания в периоде
                                        if (allTransfersArray.get(i).getDateTransfer().isBefore(localDateEnd) &&
                                                allTransfersArray.get(i).getDateTransfer().isAfter(localDateStart)) {

                                            if (allTransfersArray.get(i).getBankAccount1().equals(billsChoice.getBankAccount1())) {
                                                if (billsChoice.getAccountAmount() < allTransfersArray.get(i).getSum()) {
                                                    System.err.print(allTransfersArray.get(i).toString() + " невозможна. ");
                                                    System.err.println("Сумма на счете меньше суммы перевода");
                                                    continue;
                                                } else {
                                                    billsChoice.setAccountAmountMinus(allTransfersArray.get(i).getSum());
                                                    write_offs += allTransfersArray.get(i).getSum();
                                                }
                                            }

                                        }


                                    }
                                    System.out.println("Счет: " + billsChoice.getBankAccount1() + "\nСумма на счете до начала периода: " + sumBefore);
                                    System.out.println("Поступелния на счет в периоде: " + sumPeriod);
                                    System.out.println("Списания со счета в периоде: " + write_offs);
                                    System.out.println("Исходящий остаток: " + billsChoice.getAccountAmount());
                                    flag = 1;
                                }else {
                                    flag=0;
                                    System.err.println("Неверная дата");
                                }

                            }else {
                                flag=0;
                                System.err.println("Неправильная дата");
                            }
                        }else {
                            flag=0;
                            System.err.println("Неверная дата");

                        }
                    }else {
                        flag=0;
                        System.err.println("неправильная дата");
                    }

                }else {
                    flag=0;
                    System.err.println("нет такого счета");
                }

            }

        } catch (ArrayIndexOutOfBoundsException ex) {
            System.err.println("Ошибка переполнения массива");
            return;
        } catch (IllegalStateException q) {
            System.err.println("файл пуст или не читается");
            return;
        } catch (FileNotFoundException e) {
            System.err.println("файл не найден");
        } catch (IOException ex) {
            System.err.println("Операция ввода-вывода завершена неудачно или прервана");
            return;
        }catch (DateTimeException ex){
            System.err.println("Неверная дата");
            return;
        }


    }
}
