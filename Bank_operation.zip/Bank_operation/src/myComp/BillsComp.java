package myComp;

import com.company.Bills;

import java.util.Comparator;

public class BillsComp implements Comparator<Bills> {

    @Override
    public int compare(Bills K, Bills T){
        return (K.getBankAccount1().compareTo(T.getBankAccount1()));

    }
}
