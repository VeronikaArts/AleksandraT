package com.company;

public class Bus {
    private int number_of_seats;
    private int cost_of_one_seat;
    private int number_of_occupied_places;

    public Bus(){
        this(0,0,0);
    }

    public Bus(int number_of_seats, int cost_of_one_seat, int number_of_occupied_places){
        this.number_of_seats=number_of_seats;
        this.cost_of_one_seat=cost_of_one_seat;
        this.number_of_occupied_places=number_of_occupied_places;
    }

    public Bus(Bus bus){
        number_of_seats=bus.number_of_seats;
        cost_of_one_seat=bus.cost_of_one_seat;
        number_of_occupied_places=bus.number_of_occupied_places;
    }

    public int getNumber_of_seats(){
        return this.number_of_seats;
    }

    public void setNumber_of_seats(int number_of_seats){
        this.number_of_seats=number_of_seats;
    }

    public int getCost_of_one_seat(){
        return cost_of_one_seat;
    }

    public void setCost_of_one_seat(int cost_of_one_seat){
        this.cost_of_one_seat=cost_of_one_seat;
    }

    public int getNumber_of_occupied_places(){
        return number_of_occupied_places;
    }

    public void setNumber_of_occupied_places(int number_of_occupied_places){
        this.number_of_occupied_places=number_of_occupied_places;
    }

    //количество свободных мест
    public int free_places(){
        return this.number_of_seats-this.number_of_occupied_places;
    }

    //пуст ли автобус
    public boolean isEmptyBus(){
        if (this.number_of_seats==this.number_of_occupied_places){
            return false;
        }else return true;
    }

    //общая стоимость занятых мест
    public int sum_NOfree_places(){
        return this.cost_of_one_seat*this.number_of_occupied_places;
    }






}
