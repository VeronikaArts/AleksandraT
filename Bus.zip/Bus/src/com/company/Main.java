package com.company;

public class Main {

    public static void main(String[] args) {
        Bus bus1=new Bus(54,400,25);
        Bus bus2=new Bus(45,500,30);

        System.out.println("Первый автобус\nКоличество мест: "+bus1.getNumber_of_seats());
        System.out.println("Цена за место: "+bus1.getCost_of_one_seat());
        System.out.println("Количество занятых мест: "+bus1.getNumber_of_occupied_places());
        System.out.println("Общая стоимость занятых мест: "+bus1.sum_NOfree_places());

        if (bus1.sum_NOfree_places()>=11000){
            System.out.println("Первый автобус рентабелен");
        }
        System.out.println("\nВторой автобус\nКоличество мест: "+bus2.getNumber_of_seats());
        System.out.println("Цена за место: "+bus2.getCost_of_one_seat());
        System.out.println("Количество занятых мест: "+bus2.getNumber_of_occupied_places());
        System.out.println("Общая стоимость занятых мест: "+bus2.sum_NOfree_places());

        if (bus2.sum_NOfree_places()>=11000){
            System.out.println("Второй автобус рентабелен");
        }

    }
}
