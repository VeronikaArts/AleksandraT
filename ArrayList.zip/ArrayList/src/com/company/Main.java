package com.company;

import java.util.ArrayList;
import java.util.Collections;

public class Main {

    public static void main(String[] args) {

        ArrayList<Integer> arrayList=new ArrayList<Integer>();
        for (int i=0;i<10;i++){
            arrayList.add(((int)(Math.random() * 30)-10));
        }

        arrayList.add(7,35);
        arrayList.add(10,35);

        System.out.println("Исходный массив: ");
        for (int i=0;i<arrayList.size();i++){
            System.out.print(arrayList.get(i)+" ");
        }

        //вывести на экран значение максимального элемента;
        int max=arrayList.get(0);
        for (int i=0;i<arrayList.size();i++){
            if(max<arrayList.get(i))
                max=arrayList.get(i);
        }
        System.out.println("\nМаксимальный элемент массива: "+ max);

        //вывести на экран номер последнего элемента, равного максимальному
        int index=-1;
        for (int i=0;i<arrayList.size();i++){
            if(max==arrayList.get(i))
                index=i+1;
        }
        if (index!=-1)
            System.out.println("Номер последнего элемента, равного максимальному: "+ index);
        else
            System.out.println("Элемент, равный максимальному не найден");

        //отсортировать числа по возрастанию
        Collections.sort(arrayList);
        System.out.println("Массив, отсортированный по возрастанию:");
        for (int i=0;i<arrayList.size();i++){
            System.out.print(arrayList.get(i)+" ");
        }
        //удалить все отрицательные числа
        int j=0;
        while (j<arrayList.size()){
            if (arrayList.get(j)<0) {
                arrayList.remove(j);
            }else j++;
        }
        System.out.println("\nМассив без отрицательных элементов: ");
        for (int i=0;i< arrayList.size();i++){
            System.out.print(arrayList.get(i)+" ");
        }

    }
}
