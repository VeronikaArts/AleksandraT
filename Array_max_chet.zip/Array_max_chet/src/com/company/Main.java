package com.company;

public class Main {

    public static void main(String[] args) {
        System.out.println("Задача: заполнить массив 20 случайными целыми числами(0-1000). " +
                "\nНайти в массиве максимальное четное число.");
        int[] array = new int[20];
        int max_chet=-1;
        System.out.print("Массив: ");
        for (int i = 0; i < array.length; i++) {
            array[i] = (int) Math.round((Math.random() * 1000));
            System.out.print(array[i]+" ");
        }

        for (int i=0;i<20;i++){
            if(array[i]%2==0 && array[i]>max_chet)
                max_chet=array[i];
        }

        if(max_chet!=-1)
            System.out.println("\nМаксимальное четное число: "+max_chet);
        else System.out.println("Нет чисел, удовлетворяющих условию");


    }
}
